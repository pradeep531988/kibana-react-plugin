import { uiModules } from 'ui/modules';
import uiRoutes from 'ui/routes';

import 'ui/autoload/styles';
import '../public/components/main/main.less';
import React from 'react';
import chrome from 'ui/chrome';
import { render, unmountComponentAtNode } from 'react-dom';
import { Main } from './components/main';
import 'ui/private';
import { FeatureCatalogueRegistryProvider } from 'ui/registry/feature_catalogue';
import { PROJECT_SUCCESS_MESSAGE, PROJECT_FAILURE_MESSAGE } from './const/flip_constants';

uiRoutes.enable();
const app = uiModules.get('apps/flip-plugin', []);
app.directive('flipApp', function (reactDirective) {
  return reactDirective(Main);
});


app.config($locationProvider => {
  $locationProvider.html5Mode({
    enabled: false,
    requireBase: false,
    rewriteLinks: false,
  });

});
app.config(stateManagementConfigProvider =>
  stateManagementConfigProvider.disable()
);

function RootController($scope, $element, $http, Private) {

  let envConfig;
  let projectList = {};

  const renderUi = function ($http, projectList, projectTitle) {

    const domNode = document.getElementsByClassName('app-wrapper-panel')[0];
    // render react to DOM
    render(<Main
      httpClient={$http}
      projectList={[...new Set(projectList)]}
      projectTitle={projectTitle}
      directories={Private(FeatureCatalogueRegistryProvider)}
    />, domNode);

    // unmount react on controller destroy
    $scope.$on('$destroy', () => {
      unmountComponentAtNode(domNode);
    });
  };

  const getProjectAndRender = function (projectDataURL) {

    $http.get(projectDataURL).then((resp) => {
      projectList = resp.data;
      if(projectList) {
        return renderUi($http, projectList, PROJECT_SUCCESS_MESSAGE);
      }
      return renderUi($http, projectList, '');
    }).catch((error)=> {
      console.error('Exception while retriving project :' + error);
      Promise.resolve(error);
      return renderUi($http, '', PROJECT_FAILURE_MESSAGE);
    });
  };

  $http.get('../api/flip-plugin/config').then((resp) => {
    envConfig = resp.data.envConfig;
    if (envConfig === undefined) {
      console.error('Unable to load flip configuation');
      return false;
    }
    getProjectAndRender(envConfig.projectDataURL);
  }).catch(function (e) {
    console.error('error' + e);
  });
}

chrome.setRootController('flipReactPlugin', RootController);


import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { ProjectDetails } from '../project_details/project_details';
import chrome from 'ui/chrome';
import './home.less';
import Info from '../info/info';
import { PROJECT_NO_APP_AVAILABLE_MESSAGE_TITLE, PROJECT_NO_APP_AVAILABLE_MESSAGE_DESC1,
  PROJECT_NO_APP_AVAILABLE_MESSAGE_DESC2, PROJECT_FAILURE_MESSAGE } from '../../const/flip_constants';
import { RecentlyAccessed, recentlyAccessedShape } from '../recently_accessed/recently_accessed';
import { recentlyAccessed } from 'ui/persisted_log';

import $ from 'jquery';

import {
  EuiPageHeader,
  EuiTitle,
  EuiPage,
  EuiFlexItem,
  EuiFlexGrid,
  EuiSpacer,
  EuiFlexGroup,
  EuiPanel,
  EuiTextColor
} from '@elastic/eui';

export class Home extends React.Component {


  constructor(props) {
    super(props);
    console.log(props);
    this.state = {

      /* recentlyAccessed: recentlyAccessed.get().map(item => {
        item.link = chrome.addBasePath(item.link);
        return item;
      })*/
    };
  }
  componentDidMount() {
    //$('.global-nav-link a[href$="flip-plugin"]').css('display', 'none');
    try {
      if (localStorage.getItem('app')) {
        $('#' + localStorage.getItem('app')).addClass('activeApplication');
      }
    }catch(e) {
      console.log('unable to set style for application selected');
    }

    console.log(this.state.recentlyAccessed);

  }



  renderProjects = (projects) => {

    const addBasePath  = chrome.addBasePath;
    const quickLinks = this.props.quickLinks;
    if (projects === undefined) {
      return;
    }
    return projects
      .map((project) => {
        const projectDetailWithLinks = (
          <EuiFlexItem style={{ minHeight: 180 }}  className="projectPanel" key={project.id} id={project.id}>
            <ProjectDetails
              key={project.id + 'projectId'}
              description={project.description}
              iconUrl={addBasePath(project.icon)}
              title={project.title}
              quickLinks={this.props.quickLinks}
              defaultNaviagationLink={addBasePath('/app/kibana#/discover')}
            />
          </EuiFlexItem>
        );
        return projectDetailWithLinks;
      });
  };



  render() {
    // const cardStyle = {
    //   width: '250px',
    //   'minWidth': '200px'
    // };
    const recentlyAccessed = [
      {
        label: 'my vis',
        link: 'link_to_my_vis',
        id: '1'
      }
    ]; //TODO: To make this dynamic

    let recentlyAccessedPanel;
    if (recentlyAccessed.length > 0) {
      recentlyAccessedPanel = (
        <Fragment>
          <RecentlyAccessed
            recentlyAccessed={recentlyAccessed}
          />
          <EuiSpacer size="l" />
        </Fragment>
      );
    }

    const project = this.props.projects;
    const title = this.props.title;
    let infoMessage;
    let desc1;
    let desc2;
    if (PROJECT_FAILURE_MESSAGE === this.props.projectTitle) {
      infoMessage = PROJECT_FAILURE_MESSAGE;
    }else {
      infoMessage = PROJECT_NO_APP_AVAILABLE_MESSAGE_TITLE;
      desc1 = PROJECT_NO_APP_AVAILABLE_MESSAGE_DESC1;
      desc2 = PROJECT_NO_APP_AVAILABLE_MESSAGE_DESC2;
    }
    return (
      <EuiPage className="home">

        { /* <EuiSpacer size="s" />
        <EuiFlexGroup
          justifyContent="flexEnd"
        >
          <EuiFlexItem grow={false}>
            <select className="kuiSelect">
              <option>FireFly</option>
              <option>PAAS</option>
              <option>TAAS</option>
              <option>DATA APPLICATION</option>
            </select>
          </EuiFlexItem>
    </EuiFlexGroup> */}

        <EuiPageHeader style={{ marginBottom: 5 }}>
          <EuiTitle size="l" className="appMainTitleHeader">
            <h3>{title}</h3>
          </EuiTitle>
        </EuiPageHeader>

        { project.length > 0 ? (
          <div>
            <EuiFlexGroup gutterSize="s" className="applicationMain euiPanel euiPanel--paddingMedium">
              <EuiFlexItem>
                <EuiTitle  size="s" className="subdued">
                  <h4 style={{ marginBottom: 5 }}>
                    <EuiTextColor color="subdued">
                      {this.props.projectTitle}
                    </EuiTextColor>
                  </h4>
                </EuiTitle>
                {/* <EuiSpacer size="s"/> */}
                <EuiFlexGrid columns={4} >
                  { this.renderProjects(project) }
                </EuiFlexGrid>

              </EuiFlexItem>
            </EuiFlexGroup>
            <EuiSpacer size="l"/>

            <EuiFlexGroup gutterSize="s" className="applicationMain euiPanel euiPanel--paddingSmall">
              { recentlyAccessedPanel }
            </EuiFlexGroup>
          </div>
        ) : (
          <Info title={infoMessage} description1={desc1} description2={desc2}/>
        )
        }
      </EuiPage>
    );
  }
}

