import React from 'react';
import genericLogo from '../../icons/genericLogo.png';

import {

  EuiFlexGroup,
  EuiPanel,
  EuiFlexItem,
  EuiText,
  EuiSpacer,
  EuiFlexGrid
} from '@elastic/eui';

export default function Info() {


  return (
    <div>
      <EuiSpacer size="l" />

      <EuiFlexGroup
        gutterSize="s"
        justifyContent="center"
        className="applicationMain"
      >
        <EuiFlexItem grow={false}>

          <img
            className="projectIcon"
            src={genericLogo}
            alt=""
          />
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiFlexGroup
        gutterSize="m"
        justifyContent="center"
      >
        <EuiText>
          <h1>
              No Application Available !
          </h1>
        </EuiText>
      </EuiFlexGroup>
      <EuiSpacer size="l" />

      <EuiFlexGroup
        gutterSize="m"
        justifyContent="center"
      >
        <EuiText>
          <h2>
            You are not having access to any application.
          </h2>
        </EuiText>
      </EuiFlexGroup>
      <EuiSpacer size="m" />

      <EuiFlexGroup
        gutterSize="m"
        justifyContent="center"
      >
        <EuiText>
          <h2>
            To know more, please contact your Admin Team.
          </h2>
        </EuiText>
        <EuiSpacer size="s" />
      </EuiFlexGroup>
    </div>
  );
}
